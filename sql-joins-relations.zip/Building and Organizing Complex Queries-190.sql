## 3. The With Clause ##

WITH playlist_info AS
    (
        SELECT
            p.playlist_id,
            p.name playlist_name,
            t.name track_name,
            (t.milliseconds/1000) length_seconds
        FROM playlist p
        LEFT JOIN playlist_track pt on p.playlist_id = pt.playlist_id
        LEFT JOIN track t on pt.track_id = t.track_id
    )
    
SELECT 
    playlist_id,
    playlist_name,
    COUNT(track_name) number_of_tracks,
    SUM(length_seconds) length_seconds
FROM playlist_info
GROUP BY 1
ORDER BY 1


## 4. Creating Views ##

CREATE VIEW chinook.customer_gt_90_dollars AS
    SELECT c.* 
    FROM chinook.customer c
    INNER JOIN invoice i on c.customer_id = i.customer_id
    GROUP BY 1
    HAVING SUM(i.total) > 90;
    
SELECT * FROM chinook.customer_gt_90_dollars;

## 5. Combining Rows With Union ##

SELECT * FROM chinook.customer_gt_90_dollars
UNION
SELECT * FROM chinook.customer_usa


## 6. Combining Rows Using Intersect and Except ##

WITH customer_usa_gt_90 AS
    (
        SELECT * FROM customer_gt_90_dollars
        INTERSECT
        SELECT * FROM customer_usa
    )
    
SELECT 
    e.first_name || " " || e.last_name employee_name,
    COUNT(c.customer_id) customers_usa_gt_90
FROM employee e
LEFT JOIN customer_usa_gt_90 c on c.support_rep_id = e.employee_id
WHERE e.title = "Sales Support Agent"
GROUP BY 1
ORDER BY 1;

    

## 7. Multiple Named Subqueries ##

WITH
    customers_india AS
    (
        SELECT * from customer
        WHERE country = "India"
    ),
    sales_per_customer AS
    (
        SELECT 
        customer_id,
        SUM(total) total
        FROM invoice
        GROUP BY customer_id
    )

SELECT 
    ci.first_name || " " || ci.last_name customer_name,
    spc.total total_purchases
FROM customers_india ci
INNER JOIN sales_per_customer spc on ci.customer_id = spc.customer_id
ORDER BY 1

## 8. Challenge: Each Country's Best Customer ##

WITH 
    total_purchases AS
    (
        SELECT 
        customer_id,
        SUM(total) total_purchased
        FROM invoice
        GROUP by 1
    ),
    customer_totals AS
    (
    SELECT * FROM customer c
    INNER JOIN total_purchases tp on c.customer_id = tp.customer_id
    ),
    country_max_purchase AS
    (
        SELECT country, MAX(total_purchased) max_purchase, customer_id
        FROM customer_totals
        GROUP BY 1
    ),
    country_best_customer AS
    (
        SELECT 
            cmp.country, 
            ct.first_name || " " || ct.last_name customer_name,
            ct.total_purchased
            
        FROM customer_totals ct
        INNER JOIN country_max_purchase cmp ON cmp.customer_id = ct.customer_id
        
    )
    
    
SELECT *
FROM country_best_customer
ORDER BY 1
