## 2. Frequency Distribution ##

fandango_distribution= norm_reviews['Fandango_Ratingvalue'].value_counts().sort_index()

imdb_distribution = norm_reviews['IMDB_norm'].value_counts().sort_index()

print(fandango_distribution, "\n", imdb_distribution)

## 4. Histogram In Matplotlib ##

fig, ax = plt.subplots()

ax.hist(norm_reviews['Fandango_Ratingvalue'], range = (0,5))
plt.show()

## 5. Comparing histograms ##

# import pandas as pd
# import matplotlib.pyplot as plt
# reviews = pd.read_csv('fandango_scores.csv')

# norm_reviews = reviews[cols]
# print(norm_reviews[:5])

fig = plt.figure(figsize=(5,20))
ax1 = fig.add_subplot(4,1,1)
ax2 = fig.add_subplot(4,1,2)
ax3 = fig.add_subplot(4,1,3)
ax4 = fig.add_subplot(4,1,4)

ax_list = [ax1, ax2, ax3, ax4]
hist_list = ['Fandango_Ratingvalue', 'RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', ]

title_list = ['Distribution of Fandango Ratings',
              'Distribution of Rotten Tomatoes Ratings',
             'Distribution of Metacritic Ratings',
             'Distribution of IMDB Ratings']
for i in range(0,4):
    ax_list[i].hist(norm_reviews[hist_list[i]], 20,range = (0,5) )
    ax_list[i].set_title(title_list[i])
    ax_list[i].set_ylim((0,50))
    
plt.show()
    

    

# fig = plt.figure(figsize=(10,6))
# colors = ['red', 'blue', 'green', 'orange', 'black']

# for i in range(5):
#     start_index = i*12
#     end_index = (i+1)*12
#     subset = unrate[start_index:end_index]
#     year = str(1948 + i)
#     plt.plot(subset['MONTH'], subset['VALUE'], c=colors[i], label = year)

# plt.legend(loc = 'upper left')
# plt.show()


## 7. Box Plot ##

fig, ax = plt.subplots()

ax.boxplot(norm_reviews['RT_user_norm'])

ax.set_ylim(0,5)
ax.set_xticklabels(['Rotten Tomatoes'])
plt.show()

## 8. Multiple Box Plots ##

num_cols = ['RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue']
fig, ax = plt.subplots()
ax.boxplot(norm_reviews[num_cols].values)
ax.set_xticklabels(norm_reviews[num_cols], rotation = 90)
ax.set_ylim(0,5)
plt.show()